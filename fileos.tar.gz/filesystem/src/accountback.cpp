/*************************************************************************
	> File Name: accountback.cpp
	> Author: 
	> Mail: 
	> Created Time: Wed 26 Dec 2018 09:12:34 PM CST
 ************************************************************************/

#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
int main(int argc,char* argv[]){
    FILE* fp = fopen(argv[1],"rb");
    char usename[10];
    char password[10];
    fread(usename,sizeof(usename),1,fp);
    fread(password,sizeof(password),1,fp);
    fclose(fp);
    cout<<"usename:"<<usename<<'\n'<<"password:"<<password<<endl;
    return 0;
}

