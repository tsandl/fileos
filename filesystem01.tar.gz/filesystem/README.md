# filesystem

This is a file manager system of operator system,

work station: manjaro

language: c++


operator:

#in filesystem dir
make
