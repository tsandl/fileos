/*************************************************************************
	> File Name: main.cpp
	> Author:tsand 
	> Mail: tsxqc@hotmail.com
	> Created Time: Fri 02 Nov 2018 08:24:58 PM CST
 ************************************************************************/

#include<iostream>
#include "FileSystem.h"
using namespace std;
int main(int argc, char* argv[]) {
    cout<<"\033[32mWelcome to a simple system"<<endl;
    FileSystem file(argv[1]);
    file.init();
    cout << "Hello world!" << endl;
    return 0;

}

