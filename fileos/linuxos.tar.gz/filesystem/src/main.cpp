/*************************************************************************
	> File Name: main.cpp
	> Author: 
	> Mail: 
	> Created Time: Fri 02 Nov 2018 08:24:58 PM CST
 ************************************************************************/

#include<iostream>
#include "FileSystem.h"
using namespace std;
int main(int argc, char* argv[]) {
    FileSystem file(argv[1]);
    file.init();
    cout << "Hello world!" << endl;
    return 0;

}

